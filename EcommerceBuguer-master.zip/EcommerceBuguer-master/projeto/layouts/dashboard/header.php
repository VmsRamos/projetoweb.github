<nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-3">
    <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Dashboard</a>

    <span class="text-warning"> Bem vindo ao Painel, <?php echo $_SESSION['nome']; ?>.</span>
</nav>

